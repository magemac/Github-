package com.cos.exam01.domain;

import java.sql.Timestamp;

public class Item {
	private int itemCode;
	private String itemName;
	private int price;
	private Timestamp mDate;
	private int availableStock;
	
	@Override
	public String toString() {
		return "Item [itemCode=" + itemCode + ", itemName=" + itemName + ", price=" + price + ", mDate=" + mDate
				+ ", availableStock=" + availableStock + "]";
	}
	public Item() {
		
	}
	public Item(int itemCode, String itemName, int price, int availableStock,Timestamp mDate) {
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.price = price;
		this.mDate = mDate;
		this.availableStock = availableStock;
	}
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Timestamp getmDate() {
		return mDate;
	}
	public void setmDate(Timestamp mDate) {
		this.mDate = mDate;
	}
	public int getAvailableStock() {
		return availableStock;
	}
	public void setAvailableStock(int availableStock) {
		this.availableStock = availableStock;
	}
}
