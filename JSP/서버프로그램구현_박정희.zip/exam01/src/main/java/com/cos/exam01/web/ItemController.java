package com.cos.exam01.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cos.exam01.service.Action;
import com.cos.exam01.service.item.DeleteAction;
import com.cos.exam01.service.item.InsertAction;
import com.cos.exam01.service.item.SaveAction;

// http://localhost:9090/exam01/item?cmd=insert

@WebServlet("/item")
public class ItemController extends HttpServlet{

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doProcess(request, response);
	}

	public void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("cmd") == null || request.getParameter("cmd").equals("")) {

			return;
		}

		String cmd = request.getParameter("cmd");

		// MVC 패턴 기능 정의 완료

		Action action = router(cmd); // router에 넘김
		if (action != null) {
			action.execute(request, response);
		}
	}

	private Action router(String cmd) {

		if (cmd.equals("insert")) {

			return new InsertAction();

		} else if (cmd.equals("delete")) {

			return new DeleteAction();

		} else if (cmd.equals("saveForm")) {

		} else if (cmd.equals("save")) {
			return new SaveAction();

		} else if (cmd.equals("findAll")) {

		}
		return null;
	}

}
