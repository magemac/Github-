package com.cos.exam01.domain;

import java.util.List;

public interface CrudDAO<T> {
	
	public T findById(int itemCode) ;
	//get
	public List<T> findAll() ;
	//post
	public int save(T data) ;
	
	public int update(T data) ;
	//post
	public int delete(int itemCode);
}

