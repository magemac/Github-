package com.cos.exam01.service.item;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cos.exam01.domain.Item;
import com.cos.exam01.domain.ItemDAO;
import com.cos.exam01.service.Action;

public class SaveAction implements Action {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int itemCode = Integer.parseInt(request.getParameter("itemCode"));
		String itemName = request.getParameter("itemName");
		int price = Integer.parseInt(request.getParameter("price"));
		int availableStock = Integer.parseInt(request.getParameter("availableStock"));
		Item item = new Item();
		item.setItemCode(itemCode);	
		item.setItemName(itemName);
		item.setPrice(price);
		item.setAvailableStock(availableStock);

		ItemDAO itemDAO = new ItemDAO();
		int result = itemDAO.save(item);

		if (result == 1) {
			response.sendRedirect("/item");
		}

	}
}