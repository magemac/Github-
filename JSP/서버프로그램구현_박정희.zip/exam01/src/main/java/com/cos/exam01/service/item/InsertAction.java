package com.cos.exam01.service.item;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cos.exam01.domain.Item;
import com.cos.exam01.domain.ItemDAO;
import com.cos.exam01.service.Action;
import com.cos.exam01.util.Script;



public class InsertAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		int itemCode = Integer.parseInt(request.getParameter("itemCode"));
		String itemName = request.getParameter("itemName");
		int price = Integer.parseInt(request.getParameter("price"));
		int availableStock = Integer.parseInt(request.getParameter("availableStock"));
		
	Item item = new Item(itemCode, itemName, price, availableStock, null);
		
		// 3. DAO 연결해서 save() 하기
		// 4. result  받아야 함.
		ItemDAO itemDAO = ItemDAO.getInstance(); //싱글톤 
		int result = itemDAO.save(item);
		
		
		if(result == 1) {
			
			System.out.println("입력성공");
			
			response.sendRedirect("dbtest/insert.jsp");
			
		}else {
			
			
			Script.back("입력 실패", response);
			
		}
		
		
	}
	
}