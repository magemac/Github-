package com.cos.exam01.domain;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cos.exam01.db.DBConn;

public class ItemDAO {
	private static ItemDAO instance = new ItemDAO();
	
public ItemDAO() {
		
	}
	public static ItemDAO getInstance() {
		return instance;
	}//싱글톤
	
	public int insert(int itemCode, String itemName, int price, int availableStock) {
		try {
			String sql = "INSERT INTO item(itemcode,itemname,price,availableStock) VALUES(?,?,?,?)";
			Connection conn = DBConn.디비연결();
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, itemCode);
			pstmt.setString(2, itemName);
			pstmt.setInt(3, price);
			pstmt.setInt(4, availableStock);

			return pstmt.executeUpdate(); 
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	public int save(Item data) {
		String sql = "INSERT INTO item(itemCode,itemName,price,availableStock) VALUES(?,?,?,?)";
		System.out.println(1);
		try {
			Connection conn = DBConn.디비연결();
			System.out.println(2);	
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, data.getItemCode());
			pstmt.setString(2, data.getItemName());
			pstmt.setInt(3, data.getPrice());
			pstmt.setInt(4, data.getAvailableStock());

			return pstmt.executeUpdate(); 
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;

	}
	
	public List<Item> findAll() {
	
	
	List<Item> items = new ArrayList<>();
	String sql = "select * from item order by itemCode desc";
		try {
			
			Connection conn = DBConn.디비연결();

			
			PreparedStatement pstmt = conn.prepareStatement(sql);
	
			ResultSet rs = pstmt.executeQuery(); 
			
			while(rs.next()){
				
				Item item = new Item();
				
				item.setItemCode(rs.getInt("itemCode"));
				item.setItemName(rs.getString("itemName"));
				item.setPrice(rs.getInt("price"));
				item.setAvailableStock(rs.getInt("availableStock"));				
				items.add(item);
		
			}
			return items;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	
	
	

	public int delete(int itemCode) {
		
		String sql="DELETE FROM item WHERE itemCode=?";
		
		try {
			
			Connection conn = DBConn.디비연결();

			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			//프로토콜이 적용된 버퍼
			
			// 물음표 순서는 1부터 시작
			pstmt.setInt(1,itemCode);
			

			int result= pstmt.executeUpdate(); // 입력 뒤 커밋 시켜줌
			//ResultSet rs = pstmt.executeQuery(); //결과를 가져옴 
			//지금 특정id의 row를 가져오는건데 (row는 하나의 데이터가 아닌 집합)
			 //ResultSet으로 리턴함 리절트셋은 집합.		
		return result;
			}
			
		 catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
		
	}
	
	
	
		

	
}

