package com.cos.exam01.service.item;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cos.exam01.domain.ItemDAO;
import com.cos.exam01.service.Action;


public class SearchAction implements Action{
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	
	int itemcod = Integer.parseInt(request.getParameter("itemcode"));
	ItemDAO itemDAO = ItemDAO.getInstance();
	

	
	
}
}